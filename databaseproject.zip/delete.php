<?php
include "header.php";
    $sql = "DELETE FROM response";
    mysqli_query($conn , $sql);
    header("Location: admin.php");
?>