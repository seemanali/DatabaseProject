

<?php
  session_start();
  if(isset($_SESSION["loggedin"])){
    echo "";
  }
  else{
    header("Location: index.php");
  }

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="icon" href="img/core-img/favicon.ico">
    <title>Admin - Quddus us salam Recipes</title>
    <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
  </head>
  <body>


  <nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="logout.php">Log Out</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="NewRecipe.php">New Recipe</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="viewRecipe.php">View All Recipes</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Delete Recipe</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">update Recipe</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="cat.php">Catageries</a>
        </li>
      </ul>
    
    </div>
  </div>
</nav>

<?php
include "header.php";
$id = $_GET['id'];
$sql = "SELECT * FROM `recipe` WHERE `sid` ='{$id}' ";
$result = mysqli_query($conn , $sql);
if(!mysqli_num_rows($result)>0){
  header("Location: admin.php");
}
while($row = mysqli_fetch_assoc($result)){
  echo '<div class="receipe-content-area">
        <div class="container">

            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="receipe-headline my-5">
                        <span>April 05, 2018</span>
                        <h2>'.$row["title"].'</h2>
                        <div class="receipe-duration">
                            <h6>Cooking Time: '.$row["cookingTime"].' mins</h6>
                            <h6>Yields: '.$row["yeilds"].'  Servings</h6>
                        </div>
                    </div>
                </div>
<div class="container">
    <div class="row">
        <div class="col-12">
            <img src="'.$row["thumb"].'" alt="" width="250px">
        </div>
    </div>
</div>
</div>
<a href="confirmDelete.php?id='.$id.'" class="btn btn-danger my-5">confirm Delete</a>

';

            };
?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>
