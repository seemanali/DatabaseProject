<?php 
$id = $_GET["id"];
include "header.php";


$sql1 = "SELECT * FROM `recipe` WHERE `sid` = '{$id}'";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
// echo $row1["cata"];
$catageroyName = $row1["cata"];

$sql2 = "SELECT * FROM `cat` WHERE `catName` = '{$catageroyName}'";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);
$decr = $row2["count"]-1;

$sql3 = "UPDATE `cat` SET `count` =".$decr." WHERE `cat`.`catName` = '{$cname}'";
mysqli_query($conn,$sql3);


$sql = "DELETE FROM `recipe` WHERE `sid` = '{$id}'";
mysqli_query($conn ,$sql);

header("Location: viewRecipe.php");
?>